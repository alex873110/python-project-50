### Hexlet tests and linter status:
[![Actions Status](https://github.com/alex873110/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/alex873110/python-project-50/actions)

## Code Climate Maintainability Badge link
<a href="https://codeclimate.com/github/alex873110/python-project-50/maintainability"><img 
src="https://api.codeclimate.com/v1/badges/dafb77493b9982091195/maintainability" /></a>

## Code Climate Test Coverage Badge link
[![Test Coverage](https://api.codeclimate.com/v1/badges/dafb77493b9982091195/test_coverage)](https://codeclimate.com/github/alex873110/python-project-50/test_coverage)

## GitHub Action Badge link
[![Python CI](https://github.com/alex873110/python-project-50/actions/workflows/main.yml/badge.svg)](https://github.com/alex873110/python-project-50/actions/workflows/main.yml)

##  Links to asciinema videos with gendiff package use.

<https://asciinema.org/a/eAgnFmzdU1FujHG8FGFnbgXJv>

[![asciicast](https://asciinema.org/a/bQknzievpckedTh6ujzgz9CA5.svg)](https://asciinema.org/a/bQknzievpckedTh6ujzgz9CA5)

[![asciicast](https://asciinema.org/a/YWatx9ptw0EVDH6PfnFTUHWyT.svg)](https://asciinema.org/a/YWatx9ptw0EVDH6PfnFTUHWyT)

[![asciicast](https://asciinema.org/a/eAgnFmzdU1FujHG8FGFnbgXJv.svg)](https://asciinema.org/a/eAgnFmzdU1FujHG8FGFnbgXJv)

[![asciicast](https://asciinema.org/a/VwqJPCeXCWjWBI0bvl7yQ3kS0.svg)](https://asciinema.org/a/VwqJPCeXCWjWBI0bvl7yQ3kS0)

[![asciicast](https://asciinema.org/a/0BwTjQWg7qKyVKHdCTaYP51Ky.svg)](https://asciinema.org/a/0BwTjQWg7qKyVKHdCTaYP51Ky)
