### Hexlet tests and linter status:
[![Actions Status](https://github.com/alex873110/python-project-50/workflows/hexlet-check/badge.svg)](https://github.com/alex873110/python-project-50/actions)

##  Link to asciinema video with gendiff package use.
<https://asciinema.org/a/eAgnFmzdU1FujHG8FGFnbgXJv>

[![asciicast](https://asciinema.org/a/eAgnFmzdU1FujHG8FGFnbgXJv.svg)](https://asciinema.org/a/eAgnFmzdU1FujHG8FGFnbgXJv)
